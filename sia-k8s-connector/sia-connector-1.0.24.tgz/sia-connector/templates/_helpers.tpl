{{/*
Expand the name of the chart.
*/}}
{{- define "sia-connector.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "sia-connector.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "sia-connector.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "sia-connector.labels" -}}
helm.sh/chart: {{ include "sia-connector.chart" . }}
{{ include "sia-connector.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "sia-connector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sia-connector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "sia-connector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "sia-connector.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Maintenance-disable script embedded in the post-upgrade / post-rollback hook.
ARM (enable) is performed externally by the `helm maintenance enable` plugin.

Params (passed via dict when calling `include`):
  action         - "disable" (used only for logging)
  failHard       - true; exits 1 when any connector fails to confirm the
                   maintenance toggle, aborting the hook.
  waitForRollout - true; waits for the StatefulSet rollout to become healthy
                   (readyReplicas == replicas && currentRevision ==
                   updateRevision) before disabling maintenance. Ensures
                   maintenance is only cancelled after a verified-successful
                   upgrade/rollback.

Reads CONNECTOR_ID from each replica's `<pod>-connector-id` ConfigMap
(written by entrypoint.sh) and PUTs MAINTENANCE_BODY to
/api/connectors/{connector_id}/maintenance, verifying the response's
`maintenance` field matches what was requested.
*/}}
{{- define "sia-connector.maintenanceScript" -}}
log() { echo "[$(date -Iseconds)] $*"; }

APISERVER="https://kubernetes.default.svc"
K8S_TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)
CACERT="/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"

{{- if .waitForRollout }}
# ---------------------------------------------------------------------------
# Wait for the StatefulSet rollout to be healthy before touching maintenance.
# Ensures we only cancel maintenance mode after a verified-successful
# upgrade/rollback, not merely after the API server accepted the new spec.
# ---------------------------------------------------------------------------
log "Waiting for StatefulSet '${STATEFULSET_NAME}' rollout to become healthy (timeout ${ROLLOUT_TIMEOUT}s) ..."
DEADLINE=$(( $(date +%s) + ROLLOUT_TIMEOUT ))
ROLLOUT_OK=0
while [ "$(date +%s)" -lt "${DEADLINE}" ]; do
  SS_JSON=$(curl -sS --cacert "${CACERT}" \
    -H "Authorization: Bearer ${K8S_TOKEN}" \
    "${APISERVER}/apis/apps/v1/namespaces/${NAMESPACE}/statefulsets/${STATEFULSET_NAME}" 2>/dev/null) || true

  DESIRED=$(echo "${SS_JSON}" | jq -r '.spec.replicas // 0' 2>/dev/null || echo 0)
  READY=$(echo "${SS_JSON}" | jq -r '.status.readyReplicas // 0' 2>/dev/null || echo 0)
  CURRENT_REV=$(echo "${SS_JSON}" | jq -r '.status.currentRevision // ""' 2>/dev/null || echo "")
  UPDATE_REV=$(echo "${SS_JSON}" | jq -r '.status.updateRevision // ""' 2>/dev/null || echo "")

  if [ -n "${DESIRED}" ] && [ "${READY}" = "${DESIRED}" ] && [ "${CURRENT_REV}" = "${UPDATE_REV}" ] && [ -n "${CURRENT_REV}" ]; then
    log "StatefulSet rollout healthy: ${READY}/${DESIRED} ready, revision ${CURRENT_REV}."
    ROLLOUT_OK=1
    break
  fi
  log "Rollout not yet complete (ready=${READY}/${DESIRED}, currentRevision=${CURRENT_REV}, updateRevision=${UPDATE_REV}) — retrying in 5s ..."
  sleep 5
done

if [ "${ROLLOUT_OK}" != "1" ]; then
  log "ERROR: StatefulSet rollout did not become healthy within ${ROLLOUT_TIMEOUT}s — leaving maintenance mode ENABLED."
  exit 1
fi
{{- end }}

if [ -z "${ROOT_DOMAIN:-}" ]; then
  log "WARNING: ROOT_DOMAIN not set — token acquisition may fail."
  TENANT_URL=""
else
  # Default identity host — falls back to <tenant>.my.idaptive.app below
  # if this host is unreachable (see the HTTP 000 retry block).
  TENANT_URL="https://${IDAPTIVE_TENANT_ID}.id.${ROOT_DOMAIN}"
fi

if [ -n "${DEV_API_ENDPOINT:-}" ]; then
  CONNECTORS_API_BASE_URL="${DEV_API_ENDPOINT}/api/connectors"
elif [ -n "${TENANT_SUBDOMAIN:-}" ] && [ -n "${ROOT_DOMAIN:-}" ]; then
  CONNECTORS_API_BASE_URL="https://${TENANT_SUBDOMAIN}.dpa.${ROOT_DOMAIN}/api/connectors"
else
  log "WARNING: no API endpoint configured — skipping maintenance toggle."
  CONNECTORS_API_BASE_URL=""
fi
[ -n "${CONNECTORS_API_BASE_URL}" ] && log "Using connectors API base: ${CONNECTORS_API_BASE_URL}"

log "Requesting OAuth2 token ..."
TOKEN_RESPONSE=$(curl -sS -X POST \
  --data-urlencode "grant_type=client_credentials" \
  --data-urlencode "client_id=${SIA_USERNAME}" \
  --data-urlencode "client_secret=${SIA_PASSWORD}" \
  -w "\n%{http_code}" \
  "${TENANT_URL}/oauth2/platformtoken" 2>&1) || true
TOKEN_HTTP_CODE=$(echo "${TOKEN_RESPONSE}" | tail -1)
TOKEN_RESPONSE=$(echo "${TOKEN_RESPONSE}" | head -n -1)
if [ "${TOKEN_HTTP_CODE}" = "000" ] && echo "${TENANT_URL}" | grep -q '\.id\.'; then
  FALLBACK_URL="https://$(echo "${IDAPTIVE_TENANT_ID}" | tr '[:upper:]' '[:lower:]').my.idaptive.app"
  log "WARNING: ${TENANT_URL} unreachable (HTTP 000) — retrying with ${FALLBACK_URL} ..."
  TOKEN_RESPONSE=$(curl -sS -X POST \
    --data-urlencode "grant_type=client_credentials" \
    --data-urlencode "client_id=${SIA_USERNAME}" \
    --data-urlencode "client_secret=${SIA_PASSWORD}" \
    -w "\n%{http_code}" \
    "${FALLBACK_URL}/oauth2/platformtoken" 2>&1) || true
  TOKEN_HTTP_CODE=$(echo "${TOKEN_RESPONSE}" | tail -1)
  TOKEN_RESPONSE=$(echo "${TOKEN_RESPONSE}" | head -n -1)
  if [ "${TOKEN_HTTP_CODE}" = "200" ]; then
    log "Fallback succeeded — using ${FALLBACK_URL}"
    TENANT_URL="${FALLBACK_URL}"
  fi
fi
ACCESS_TOKEN=$(echo "${TOKEN_RESPONSE}" | jq -r '.access_token // empty' 2>/dev/null || true)

FAILED=0

if [ -z "${ACCESS_TOKEN}" ]; then
  log "WARNING: could not obtain access token — skipping maintenance toggle. Response: ${TOKEN_RESPONSE}"
  FAILED=1
elif [ -z "${CONNECTORS_API_BASE_URL}" ]; then
  log "WARNING: no API endpoint configured — skipping maintenance toggle."
  FAILED=1
else
  log "Access token obtained."

  i=0
  while [ "$i" -lt "$REPLICAS" ]; do
    POD_NAME="${STATEFULSET_NAME}-${i}"
    CM_NAME="${POD_NAME}-connector-id"
    log "Reading connector ID from ConfigMap '${CM_NAME}' ..."

    CM_RESPONSE=$(curl -sS --cacert "${CACERT}" \
      -H "Authorization: Bearer ${K8S_TOKEN}" \
      "${APISERVER}/api/v1/namespaces/${NAMESPACE}/configmaps/${CM_NAME}" 2>/dev/null) || true
    CONNECTOR_ID=$(echo "${CM_RESPONSE}" | jq -r '.data.connector_id // empty' 2>/dev/null || true)

    if [ -n "${CONNECTOR_ID}" ] && [ "${CONNECTOR_ID}" != "null" ]; then
      MAINTENANCE_URL="${CONNECTORS_API_BASE_URL}/${CONNECTOR_ID}/maintenance"
      log "Setting maintenance mode for connector ${CONNECTOR_ID} -> ${MAINTENANCE_URL} body=${MAINTENANCE_BODY}"

      HTTP_STATUS=$(curl -sS -X PUT \
        -H "Authorization: Bearer ${ACCESS_TOKEN}" \
        -H "Content-Type: application/json" \
        -d "${MAINTENANCE_BODY}" \
        -o /tmp/maintenance_resp.json \
        -w "%{http_code}" \
        "${MAINTENANCE_URL}" 2>&1) || true
      RESP_BODY=$(cat /tmp/maintenance_resp.json 2>/dev/null || echo "")

      if [ "${HTTP_STATUS}" != "200" ]; then
        log "WARNING: maintenance toggle for ${CONNECTOR_ID} failed (HTTP ${HTTP_STATUS}). Response: ${RESP_BODY}"
        FAILED=1
      else
        RESP_MAINTENANCE=$(echo "${RESP_BODY}" | jq -r '.maintenance // empty' 2>/dev/null || true)
        EXPECTED_MAINTENANCE=$(echo "${MAINTENANCE_BODY}" | jq -r '.maintenance // empty' 2>/dev/null || true)

        if [ "${RESP_MAINTENANCE}" = "${EXPECTED_MAINTENANCE}" ]; then
          log "Connector ${CONNECTOR_ID} maintenance mode confirmed: ${RESP_MAINTENANCE}"
        else
          log "WARNING: connector ${CONNECTOR_ID} returned maintenance=${RESP_MAINTENANCE}, expected ${EXPECTED_MAINTENANCE}"
          FAILED=1
        fi
      fi
    else
      log "WARNING: ConfigMap '${CM_NAME}' not found or has no connector_id — skipping."
      FAILED=1
    fi
    i=$((i + 1))
  done
fi

log "Maintenance toggle complete (action={{ .action }}, failures=${FAILED})."
{{- if .failHard }}
if [ "${FAILED}" != "0" ]; then
  log "ERROR: one or more connectors failed to confirm maintenance toggle (action={{ .action }}) — aborting."
  exit 1
fi
{{- end }}
{{- end -}}

